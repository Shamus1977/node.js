module.exports = {
    "secretKey": "12345-67890-09876-54321",
    "mongoUrl": "mongodb://localhost:27017/nucampsite",
    'facebook':{
        clientId:'284781133101072',
        clientSecret:'b10ddc0b1edc552120a124727807a1da'
    }
}